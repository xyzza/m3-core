#coding:utf-8

from m3.ui.gears.edit_windows import GearEditWindow
from m3.ui.ext.fields import ExtStringField, ExtImageUploadField, ExtHiddenField, ExtComboBox
from m3.ui.ext.fields.base import BaseExtTriggerField
from m3.ui.ext.misc import ExtDataStore

import models

class EditNodeWindow(GearEditWindow):
    """
    Окно добавления/редактирования марки авто
    """

    def __init__(self, create_new = False, *args, **kwargs):
        super(EditNodeWindow, self).__init__(*args, **kwargs)

        self.frozen_size(600, 200)

        self.title = u'Марка авто'

        self.field_code = ExtStringField(label=u'Код', name='code', anchor='100%',
            allow_blank=False)
        self.field_name = ExtStringField(label=u'Наименование', name='name', anchor='100%',
            allow_blank=False)
        self.field_country = ExtStringField(label=u'Страна производитель', name='country', anchor='100%',
            allow_blank=False)
        self.field_logo = ExtImageUploadField(label=u'Лого', anchor='100%', name='logo')
        self.field_parent_id = ExtHiddenField(name='parent_id')
        self.field_id = ExtHiddenField(name='id')

        self.form.items.extend([
            self.field_code,
            self.field_name,
            self.field_country,
            self.field_logo,
            self.field_parent_id,
            self.field_id
        ])


class EditWindow(GearEditWindow):
    """
    """

    def __init__(self, create_new = False, *args, **kwargs):
        super(EditWindow, self).__init__(*args, **kwargs)

        self.frozen_size(600, 200)

        self.title = u'Карта авто'

        self.field_code = ExtStringField(label=u'Код', name='code', anchor='100%', allow_blank=False)
        self.field_name = ExtStringField(label=u'Наименование', name='name', anchor='100%', allow_blank=False)
        self.field_type = ExtComboBox(label=u'Тип кузова', display_field='type', name='type'
            ,anchor='100%', editable=False, value_field = 'id', allow_blank=False)

        self.field_type.store = ExtDataStore(data=models.AutoCard.AUTO_TYPE)
        self.field_type.trigger_action = BaseExtTriggerField.ALL

        self.form.items.extend([
            self.field_code,
            self.field_name,
            self.field_type,
            ExtHiddenField(name='parent_id'),
            ExtHiddenField(name='id')
        ])