#coding:utf-8

from m3.ui.actions.dicts.tree import BaseTreeDictionaryModelActions

import models
import ui

class CarsDictionaryActions(BaseTreeDictionaryModelActions):
    """
    """

    title = u'Авто справочник'

    url = r'/cars'

    tree_model = models.MarkCard
    tree_columns = [('name', u'Наименование марки'), ('country', u'Страна')]

    list_model = models.AutoCard
    list_columns = [('name', u'Наименование авто'), ('verbose_type', u'Тип кузова')]

    edit_node_window = ui.EditNodeWindow
    edit_window = ui.EditWindow