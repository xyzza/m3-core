#coding:utf-8
from django.db import models

from m3.core.json import json_encode

class MarkCard(models.Model):
    """
    Карточка марки автомобиля
    """

    # Код марки
    code = models.PositiveIntegerField()

    # Наименование
    name = models.CharField(max_length=150)

    # Страна производитель
    country = models.CharField(max_length=150)

    # Ссылка на родителя
    parent = models.ForeignKey('MarkCard', blank=True, null=True)

    # Логотип
    logo = models.ImageField(upload_to='/uploads')


class AutoCard(models.Model):
    """
    Карточка автомобиля
    """

    AUTO_TYPE = (
        (0, u'Седан'),
        (1, u'Хэтчбек'),
        (2, u'Универсал'),
        (3, u'Паркетник'),
        (4, u'Внедорожник'),
        (5, u'Микро')
    )

    # Код автомобиля
    code = models.PositiveIntegerField()

    # Наименование авто
    name = models.CharField(max_length=150)

    # Марка авто
    parent = models.ForeignKey(MarkCard)

    # Тип кузова
    type = models.SmallIntegerField(choices=AUTO_TYPE)

    @json_encode
    def verbose_type(self):
        return self.AUTO_TYPE[self.type][1]