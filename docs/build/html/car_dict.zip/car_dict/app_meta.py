#coding: utf-8

from django.conf import urls

from m3.ui import app_ui
from m3.ui.actions import ActionController

from m3_users.metaroles import get_metarole

from m3_blank.users import metaroles

import actions

cars_dictionary_controller = ActionController(url='/cars_dictionary')

def cars_dictionary_view(request):
    """
    """

    return cars_dictionary_controller.process_request(request)


def register_actions():
    cars_dictionary_controller.packs.extend([
        actions.CarsDictionaryActions
    ])

def register_urlpatterns():
    """
    Регистрация конфигурации урлов для приложения
    """

    return urls.defaults.patterns('',
        (r'^cars_dictionary/', cars_dictionary_view))

def register_desktop_menu():

    main_group = app_ui.DesktopLaunchGroup(name=u'Справочники')

    main_group.subitems.extend([
        app_ui.DesktopShortcut(name=u'Справочник авто', pack=actions.CarsDictionaryActions)
    ])

    app_ui.DesktopLoader.add(get_metarole(metaroles.ADMIN), app_ui.DesktopLoader.START_MENU, main_group)